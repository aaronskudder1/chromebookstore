import { IProduct } from '../../app/catalog/product.model';
export const Products: IProduct[] = [

   {
        id: 1,
        description:
          'HP Chromebook 11 G8 EE - 11.6in. HD Display, Intel Celeron N3060, 4GB RAM, 32GB eMMC Storage, Chrome OS, Grey',
        name: 'HP Chromebook 11 G8 EE',
        imageName: 'HPG8-11in.png',
        category: 'HP',
        price: 120,
        discount: 0.2,
      },
      {
        id: 17,
        description: 'Acer C733 - 11.6in. HD Display, Intel Celeron N3060, 4GB RAM, 32GB eMMC Storage, Chrome OS, Grey',
        name: 'Acer C733',
        imageName: 'AcerC733.png',
        category: 'Acer',
        price: 100,
        discount: 0,
      },
      {
        id: 6,
        description:
          'Lenovo 300e - 11.6in. Display, Intel Celeron N4000, 4GB RAM, 64GB eMMC Storage, Chrome OS, Grey',
        name: 'Lenovo 300e',
        imageName: 'Lenovo300e.png',
        category: 'Lenovo',
        price: 200,
        discount: 0,
      },
      {
        id: 2,
        description:
          'HP Chromebook 11 G6 4gb RAM - 11.6in. HD Display, Intel Celeron N3350, 4GB RAM, 32GB eMMC Storage, Chrome OS, Grey',
        name: 'HP Chromebook 11 G6',
        imageName: 'hpChromebookG6.png',
        category: 'HP',
        price: 90.0,
        discount: 0.2,
      },
      {
        id: 3,
        description:
          'HP Chromebook G4 2gb RAM - 11.6in. HD Display, Intel Celeron N3060, 2GB RAM, 16GB eMMC Storage, Chrome OS, Grey',
        name: 'HP Chromebook G4',
        imageName: 'HPcbg4.png',
        category: 'HP',
        price: 60,
        discount: 0,
      },
      {
        id: 16,
        description:
          'Samsung Chromebook 4 - 11.6in. HD Display, Intel Celeron N4000, 4GB RAM, 32GB eMMC Storage, Chrome OS, Grey',
        name: 'Samsung Chromebook 4',
        imageName: 'SamsungChromebook4.png',
        category: 'Samsung',
        price: 200,
        discount: 0.1,
      },
      {
        id: 4,
        description: 'Acer C731 - 11.6in. HD Display, Intel Celeron N3060, 4GB RAM, 32GB eMMC Storage, Chrome OS, Grey',
        name: 'Acer C731',
        imageName: 'AcerC731.png',
        category: 'Acer',
        price: 80.0,
        discount: 0,
      },
      {
        id: 9,
        description:
          'An arm with a propeller -- good for propulsion or as a cooling fan.',
        name: 'Propeller Arm',
        imageName: 'arm-propeller.png',
        category: 'Lenovo',
        price: 230,
        discount: 0.1,
      },
  ];